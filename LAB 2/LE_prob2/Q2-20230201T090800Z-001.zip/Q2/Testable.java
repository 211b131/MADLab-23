interface Testable
{
    void display();
}