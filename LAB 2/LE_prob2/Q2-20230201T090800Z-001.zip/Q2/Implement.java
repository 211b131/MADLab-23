class Implements extends Abstr{
    
}