abstract class Abstr implements Testable
{
    public void display()
    {
        System.out.println("I am in Abstr");
    }
}